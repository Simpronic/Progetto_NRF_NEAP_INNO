*****************************************************************************
** PLAY Embedded demos - 7-Segment Display and STM32                       **
*****************************************************************************

*** About ***
This demo runs on STM32 Nucleo-64 F401RE. The aim of this demo is to drive
a 8x8 LED matrix with a STM32 using ChibiOS.

*** Related article ***
For more information read the article "STM32, ChibiOS and a 8×8 LED Matrix".
http://www.playembedded.org/blog/stm32-chibios-and-a-8x8-led-matrix/

*** ChibiOS related version ***
Tested under ChibiOS 21.11.1